package com.student.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestTemplate;

import com.student.entity.Student;
import com.student.repository.StudentRepository;
import com.student.responseTemplate.College;
import com.student.responseTemplate.ResponseTemplate;

public class StudentService {
	
	
	@Autowired
	private StudentRepository stuRepo;
	
	@Autowired
	private RestTemplate restTemplate;
	

	
	public Student add(Student stu) {
		// TODO Auto-generated method stub
		return stuRepo.save(stu);
	}

	
	public List<Student> list() {
		// TODO Auto-generated method stub
		return stuRepo.findAll();
	}

	
	public Student searchById(long id) {
		// TODO Auto-generated method stub
		return stuRepo.findById(id);
	}

	
	public ResponseTemplate stuWithClg(long stuId) {
		// TODO Auto-generated method stub
		ResponseTemplate RT = new ResponseTemplate();
		Student stu = stuRepo.findById(stuId);
		
		long clg_id =stu.getClg_id();
		College clg = restTemplate.getForObject("http://College-SERVICE/college/"+clg_id, College.class);
		RT.setCollege(clg);
		RT.setStudent(stu);
		return RT;
	}
	
	
	public Student assignCollege(long stuId, long clgId) {
		// TODO Auto-generated method stub
		Student stu = stuRepo.findById(stuId);
		College clg = restTemplate.getForObject("http://COLLEGE-SERVICE/college/"+clgId, College.class);
		if(stu==null || clg==null)
		{
			return null;
		}
		stu.setClg_id(clgId);
		stuRepo.save(stu);
		return stu;
	
		
	}

	
	public List<Student> getByClgId(long clg_id) {
		// TODO Auto-generated method stub
		return stuRepo.getByClgId(clg_id);
	}

	public List<Student> getStudentByCollegeWithDescAge(long clg_id) {
		// TODO Auto-generated method stub
		return stuRepo.getStudentByCollegeWithDescAge(clg_id);   
	}
	
	

}






